// legalworkspace/handlers/legalHandlers.js
import { legalRegisterDoc } from "../../admin/legacy/adminHandlers.js";

export { legalRegisterDoc };
