// legalworkspace/handlers/registerDoc.js
import { createHash } from "crypto";
import { ApiError } from "../../src/utils/errors.js";
import {
  supabaseRestInsert,
  supabaseRestUpsert
} from "../../shared/supabase/client.js";

function parseAdminEmails() {
  const raw = process.env.ADMIN_EMAILS || "";
  return raw
    .split(",")
    .map((entry) => entry.trim().toLowerCase())
    .filter(Boolean);
}

function requireAdminAccess({ email, adminCode }) {
  const expectedCode = process.env.ADMIN_CODE || "309309";

  if (!adminCode || String(adminCode) !== String(expectedCode)) {
    throw new ApiError("ADMIN_CODE_INVALID", 403, "Admin code invalid");
  }

  const adminEmails = parseAdminEmails();
  if (adminEmails.length && !adminEmails.includes(email.toLowerCase())) {
    throw new ApiError(
      "ADMIN_EMAIL_FORBIDDEN",
      403,
      "Admin email is not allowed"
    );
  }
}

function hashPayload(payload) {
  const json = JSON.stringify(payload);
  return createHash("sha256").update(json).digest("hex");
}

export async function handleRegisterDoc({ body, user, adminCode }) {
  const role =
    typeof body?.role === "string" ? body.role.toUpperCase() : null;

  const email =
    typeof body?.email === "string" ? body.email.trim().toLowerCase() : null;

  const accountType =
    typeof body?.accountType === "string"
      ? body.accountType.toUpperCase()
      : null;

  const docType =
    typeof body?.docType === "string"
      ? body.docType.toUpperCase()
      : null;

  const docNumber = body?.docNumber;
  const template = body?.template ?? null;
  const meta = body?.meta ?? null;
  const isActive = body?.isActive ?? true;

  if (!role || !email || !accountType || !docType || !docNumber) {
    throw new ApiError(
      "VALIDATION_ERROR",
      400,
      "role, email, accountType, docType, and docNumber are required"
    );
  }

  if (!["CLIENT", "MITRA"].includes(role)) {
    throw new ApiError(
      "VALIDATION_ERROR",
      400,
      "role must be CLIENT or MITRA"
    );
  }

  // Hard security gate
  requireAdminAccess({
    email: user?.email || "",
    adminCode
  });

  const record = {
    role,
    email,
    account_type: accountType,
    doc_type: docType,
    doc_number: docNumber,
    template,
    meta,
    is_active: isActive
  };

  const registry = await supabaseRestUpsert({
    table: "legal_registry",
    record,
    onConflict: "role,email,doc_type,doc_number"
  });

  const registryRow = Array.isArray(registry) ? registry[0] : registry;

  const payload = {
    role,
    email,
    accountType,
    docType,
    docNumber,
    template,
    meta,
    isActive
  };

  // Immutable audit log
  await supabaseRestInsert({
    table: "audit_log",
    record: {
      actor_uid: user?.uid || null,
      actor_role: "ADMIN",
      actor_email: user?.email || null,
      action: "LEGAL_REGISTRY_UPSERT",
      entity_type: "legal_registry",
      entity_id: registryRow?.id || null,
      target_doc: `${docType}:${docNumber}`,
      payload_hash: hashPayload(payload),
      payload
    }
  });

  return { registry: registryRow };
}
