import { getSupabase } from "../../src/db/supabase.js";
import { ApiError } from "../../src/utils/errors.js";
import { resolveRole } from "../../src/middleware/role.js";

async function upsertProfile(client, { uid, email, role }) {
  const { error } = await client
    .from("profiles")
    .upsert({ uid, email, role }, { onConflict: "uid" });

  if (error) {
    throw new ApiError(
      "PROFILE_UPSERT_FAILED",
      500,
      "Failed to upsert profile",
      error.message
    );
  }
}

async function getMitraProfile(client, uid) {
  const { data, error } = await client
    .from("mitra_profiles")
    .select("*")
    .eq("uid", uid)
    .single();

  // PGRST116 = "Results contain 0 rows" (treat as not found)
  if (error && error.code !== "PGRST116") {
    throw new ApiError(
      "MITRA_FETCH_FAILED",
      500,
      "Failed to fetch mitra profile",
      error.message
    );
  }

  return data || null;
}

export async function whoAmI(user) {
  if (!user) {
    throw new ApiError("UNAUTHORIZED", 401, "Missing user");
  }

  const client = getSupabase();
  const role = (await resolveRole(user, { client })) || "UNKNOWN";

  await upsertProfile(client, {
    uid: user.uid,
    email: user.email,
    role,
  });

  let mitra = null;

  if (role === "MITRA") {
    mitra = await getMitraProfile(client, user.uid);
  }

  return {
    uid: user.uid,
    email: user.email,
    role,
    mitra,
  };
}

export async function requestLinkRegistry(payload) {
  const {
    role,
    accountType,
    docType,
    docNumber,
    email,
  } = payload || {};

  const client = getSupabase();

  // ADMIN: tidak perlu registry
  if (role === "ADMIN") {
    return { allowed: true };
  }

  // CLIENT/MITRA: wajib docNumber
  if (!docNumber) {
    return { allowed: false, message: "Nomor dokumen wajib diisi" };
  }

  const { data, error } = await client
    .from("legal_registry")
    .select("id, template, is_active")
    .eq("role", role)
    .eq("account_type", accountType)
    .eq("doc_type", docType)
    .eq("doc_number", docNumber)
    .eq("email", email)
    .eq("is_active", true)
    .limit(1)
    .maybeSingle();

  if (error) {
    throw new ApiError(
      "REGISTRY_LOOKUP_FAILED",
      500,
      "Registry lookup failed",
      error.message
    );
  }

  if (!data) {
    return {
      allowed: false,
      message: "Registry tidak valid / belum didaftarkan admin",
    };
  }

  return {
    allowed: true,
    docType,
    template: data.template || null,
  };
}
