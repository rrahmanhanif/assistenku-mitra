import { getSupabase, insertAudit } from "../../src/db/supabase.js";
import { ApiError } from "../../src/utils/errors.js";

export async function customerCreateOrder({ customerUid, payload }) {
  if (!customerUid) {
    throw new ApiError("VALIDATION_ERROR", 400, "customerUid is required");
  }

  const client = getSupabase();

  const { data, error } = await client
    .from("orders")
    .insert({ customer_uid: customerUid, status: "ORDER_CREATED" })
    .select()
    .single();

  if (error) {
    throw new ApiError(
      "ORDER_CREATE_FAILED",
      500,
      "Failed to create order",
      error.message
    );
  }

  await insertAudit({
    actorUid: customerUid,
    actorRole: "CUSTOMER",
    action: "CUSTOMER_CREATE_ORDER",
    entityType: "orders",
    entityId: data.id,
    payload: payload || {},
  });

  return data;
}
