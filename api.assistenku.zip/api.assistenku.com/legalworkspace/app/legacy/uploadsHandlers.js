import { getSupabase } from "../../src/db/supabase.js";
import { ApiError } from "../../src/utils/errors.js";

export async function signUpload({ bucket, path, contentType }) {
  if (!bucket || !path) {
    throw new ApiError(
      "VALIDATION_ERROR",
      400,
      "bucket and path are required"
    );
  }

  let client;
  try {
    client = getSupabase();
  } catch (err) {
    throw new ApiError(
      "NOT_CONFIGURED",
      500,
      "Supabase is not configured for uploads",
      err.message
    );
  }

  const { data, error } = await client.storage
    .from(bucket)
    .createSignedUploadUrl(path, 600);

  if (error) {
    throw new ApiError(
      "UPLOAD_SIGN_FAILED",
      500,
      "Failed to create signed upload URL",
      error.message
    );
  }

  return {
    ...data,
    path,
    contentType,
    expiresIn: 600,
  };
}
