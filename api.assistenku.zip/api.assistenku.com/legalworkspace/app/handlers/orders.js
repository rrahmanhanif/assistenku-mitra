// app/handlers/orders.js
import { customerCreateOrder } from "../legacy/customerHandlers.js";

export async function handleCustomerCreateOrder({ body, user }) {
  return customerCreateOrder(
    {
      customerUid: user.uid,
      payload: body,
    },
    user
  );
}
