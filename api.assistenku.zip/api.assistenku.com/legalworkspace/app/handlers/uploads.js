// app/handlers/uploads.js
import { signUpload } from "../legacy/uploadsHandlers.js";

export async function handleSignUpload({ body, user }) {
  return signUpload(body, user);
}
