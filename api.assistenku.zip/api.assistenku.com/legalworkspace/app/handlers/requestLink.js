import { ApiError } from "../../src/utils/errors.js";
import { supabaseRestRequest } from "../../shared/supabase/client.js";

function parseAdminEmails() {
  const raw = process.env.ADMIN_EMAILS || "";
  return raw
    .split(",")
    .map((entry) => entry.trim().toLowerCase())
    .filter(Boolean);
}

function normalizeRole(role) {
  return typeof role === "string" ? role.trim().toUpperCase() : "";
}

function requireAdminAccess({ email, adminCode }) {
  const expectedCode = process.env.ADMIN_CODE || "309309";
  if (!adminCode || String(adminCode) !== String(expectedCode)) {
    return { allowed: false, message: "Admin code tidak valid" };
  }

  const adminEmails = parseAdminEmails();
  if (adminEmails.length && !adminEmails.includes(email.toLowerCase())) {
    return { allowed: false, message: "Email admin tidak diizinkan" };
  }

  return { allowed: true, message: "Admin diizinkan" };
}

export async function requestLinkRegistry(payload) {
  const { role, accountType, docType, docNumber, email, adminCode } = payload || {};

  const normalizedRole = normalizeRole(role);
  const normalizedEmail = typeof email === "string" ? email.trim().toLowerCase() : "";
  const normalizedAccountType =
    typeof accountType === "string" ? accountType.toUpperCase() : accountType;
  const normalizedDocType = typeof docType === "string" ? docType.toUpperCase() : docType;

  if (!normalizedRole || !normalizedEmail) {
    throw new ApiError("VALIDATION_ERROR", 400, "role and email are required");
  }

  if (normalizedRole === "ADMIN") {
    const adminResult = requireAdminAccess({
      email: normalizedEmail,
      adminCode
    });

    return {
      allowed: adminResult.allowed,
      message: adminResult.message,
      data: {
        normalized: {
          role: normalizedRole,
          email: normalizedEmail
        }
      }
    };
  }

  if (!["CLIENT", "MITRA"].includes(normalizedRole)) {
    throw new ApiError("VALIDATION_ERROR", 400, "role must be ADMIN, CLIENT, or MITRA");
  }

  if (!docNumber || !normalizedAccountType || !normalizedDocType) {
    return {
      allowed: false,
      message: "accountType, docType, dan docNumber wajib diisi",
      data: {
        normalized: {
          role: normalizedRole,
          email: normalizedEmail
        }
      }
    };
  }

  const registry = await supabaseRestRequest({
    table: "legal_registry",
    select: "id, template, is_active",
    filters: [
      { column: "role", operator: "eq", value: normalizedRole },
      { column: "account_type", operator: "eq", value: normalizedAccountType },
      { column: "doc_type", operator: "eq", value: normalizedDocType },
      { column: "doc_number", operator: "eq", value: docNumber },
      { column: "email", operator: "eq", value: normalizedEmail },
      { column: "is_active", operator: "eq", value: true }
    ]
  });

  const match = Array.isArray(registry) ? registry[0] : null;

  if (!match) {
    return {
      allowed: false,
      message: "Registry tidak valid / belum didaftarkan admin",
      data: {
        normalized: {
          role: normalizedRole,
          email: normalizedEmail,
          accountType: normalizedAccountType,
          docType: normalizedDocType,
          docNumber
        }
      }
    };
  }

  return {
    allowed: true,
    message: "Registry valid",
    data: {
      normalized: {
        role: normalizedRole,
        email: normalizedEmail,
        accountType: normalizedAccountType,
        docType: normalizedDocType,
        docNumber
      },
      template: match.template || null
    }
  };
}
