// app/handlers/auth.js
import { whoAmI } from "../legacy/authHandlers.js";
import { requestLinkRegistry } from "./requestLink.js";

export async function handleWhoAmI({ user }) {
  return whoAmI(user);
}

export async function handleRequestLinkRegistry({ body }) {
  return requestLinkRegistry(body);
}
