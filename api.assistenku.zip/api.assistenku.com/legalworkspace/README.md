Assistenku API

Production API is served from https://api.assistenku.com
. This repo provides:

/api/**: thin adapters (CORS + body parsing + auth) that call domain handlers.

/admin/handlers/**: admin domain business logic.

/app/handlers/**: customer/app domain business logic.

/mitra/handlers/**: mitra domain business logic.

/legalworkspace/handlers/**: legal workspace domain business logic.

/shared/http/**: CORS + body parsing + JSON responses.

/shared/auth/**: Firebase Admin verification + role gating.

/shared/db/**: Supabase client factory (service role + anon).

/shared/utils/**: error helpers.

Environment variables

Set these in Vercel (Project Settings → Environment Variables) for all environments (Preview/Production/Development).

Variable	Description
SUPABASE_URL	Supabase project URL
SUPABASE_SERVICE_ROLE_KEY	Supabase service role key (server-side only)
SUPABASE_ANON_KEY	Supabase anon key (optional)
FIREBASE_PROJECT_ID	Firebase project ID
FIREBASE_CLIENT_EMAIL	Firebase service account client email
FIREBASE_PRIVATE_KEY	Firebase private key (replace literal \n with newlines)
CRON_SECRET	Secret for /api/internal/keepalive authentication
ADMIN_EMAILS	Comma-separated admin email allowlist
ADMIN_CODE	Admin code for admin endpoints
API_BASE_URL	Base URL for legacy proxying from other repos
EVIDENCE_BUCKET	Supabase Storage bucket for evidence uploads (default: legal-evidence)
SIGNED_URL_TTL_SECONDS	TTL for signed storage URLs (default: 3600)
Keep-alive (Supabase)

Public health check:
GET /api/health (no auth)

Internal keep-alive:
GET /api/internal/keepalive?secret=<CRON_SECRET>
or
Authorization: Bearer <CRON_SECRET>

Cron setup (Vercel)
{
  "crons": [
    {
      "path": "/api/internal/keepalive",
      "schedule": "*/15 * * * *"
    }
  ]
}

Evidence storage (legalworkspace.assistenku.com)
Manual setup

Create a private Supabase Storage bucket named:

legal-evidence


(or set env EVIDENCE_BUCKET if custom)

Ensure service role key has full access to bucket.

Signed URL flow (Mitra portal)

Create / update draft worklog

Request signed upload URL

Upload file directly to Supabase Storage

Attach evidence metadata

Submit worklog

System locks worklog after validation

Curl examples

Replace <TOKEN> with Firebase ID Token.

# Create or update draft worklog
curl -i -X POST https://api.assistenku.com/api/mitra/worklogs/create-or-update \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"docType":"SPL","docNumber":"SPL-001","date":"2024-01-10","hours":2,"notes":"Draft"}'


# Request signed upload URL
curl -i -X POST https://api.assistenku.com/api/mitra/worklogs/evidence/upload-url \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"docType":"SPL","docNumber":"SPL-001","date":"2024-01-10","filename":"photo.jpg","contentType":"image/jpeg"}'


# Attach evidence metadata
curl -i -X POST https://api.assistenku.com/api/mitra/worklogs/evidence/attach \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"docNumber":"SPL-001","date":"2024-01-10","objectPath":"evidence/SPL/SPL-001/<worklogId>/photo.jpg","filename":"photo.jpg","contentType":"image/jpeg","size":12345}'


# Submit worklog
curl -i -X POST https://api.assistenku.com/api/mitra/worklogs/submit \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"docNumber":"SPL-001","date":"2024-01-10"}'


# Lock worklog
curl -i -X POST https://api.assistenku.com/api/mitra/worklogs/lock \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"docNumber":"SPL-001","date":"2024-01-10"}'


# Signed view URL
curl -i -X GET \
"https://api.assistenku.com/api/evidence/view-url?objectPath=evidence/SPL/SPL-001/<worklogId>/photo.jpg" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "X-Admin-Code: <ADMIN_CODE>"

Deploying to Vercel
npm i -g vercel
vercel link
vercel --prod


Set all environment variables

Push to main branch → auto deploy

Testing endpoints

Replace <TOKEN> with Firebase ID token.

# Health
curl -i https://api.assistenku.com/api/health

# Who am I
curl -i -X POST https://api.assistenku.com/api/auth/whoami \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{}'

# Activate mitra (ADMIN)
curl -i -X POST https://api.assistenku.com/api/admin/mitra/activate \
  -H "Authorization: Bearer <TOKEN>" \
  -H "X-Admin-Code: <ADMIN_CODE>"

Status

This API supports:

Passwordless login (email link)

Registry-based access (IPL / SPL / Addendum / Quotation)

Signed upload & view evidence

Append-only audit logging

Role-based access (Admin / Client / Mitra)

Kalau mau, saya bisa buatkan versi README:

lebih ringkas untuk publik

versi developer internal

atau versi diagram arsitektur (flowchart login, upload, approval, dll)
