import { getSupabase, insertAudit } from "../../src/db/supabase.js";
import { ApiError } from "../../src/utils/errors.js";

export async function adminActivateMitra({ uid }, actor) {
  if (!uid) {
    throw new ApiError("VALIDATION_ERROR", 400, "uid is required");
  }

  const client = getSupabase();

  const { data, error } = await client
    .from("mitra_profiles")
    .upsert({ uid, status: "ACTIVE" }, { onConflict: "uid" })
    .select()
    .single();

  if (error) {
    throw new ApiError(
      "MITRA_ACTIVATE_FAILED",
      500,
      "Failed to activate mitra",
      error.message
    );
  }

  await insertAudit({
    actorUid: actor.uid,
    actorRole: "ADMIN",
    action: "ADMIN_ACTIVATE_MITRA",
    entityType: "mitra_profiles",
    entityId: uid,
    payload: { status: "ACTIVE" },
  });

  return data;
}
