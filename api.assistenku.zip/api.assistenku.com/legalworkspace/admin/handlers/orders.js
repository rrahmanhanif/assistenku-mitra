// admin/handlers/orders.js
import { adminAssignOrder } from "../legacy/adminHandlers.js";

export async function handleOrderAssign({ body, user }) {
  return adminAssignOrder(
    {
      orderId: body?.orderId,
      mitraUid: body?.mitraUid,
    },
    user
  );
}
