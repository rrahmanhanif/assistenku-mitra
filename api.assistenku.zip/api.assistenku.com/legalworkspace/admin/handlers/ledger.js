import { supabaseRestRequest } from "../../shared/supabase/client.js";

function summarizeCounts(items, key) {
  return items.reduce((acc, item) => {
    const value = item?.[key] ?? "UNKNOWN";
    acc[value] = (acc[value] || 0) + 1;
    return acc;
  }, {});
}

export async function handleLedgerOverview() {
  const registries = await supabaseRestRequest({
    table: "legal_registry",
    select: "role,is_active"
  });

  const worklogs = await supabaseRestRequest({
    table: "worklogs",
    select: "status"
  });

  const registryItems = Array.isArray(registries) ? registries : [];
  const worklogItems = Array.isArray(worklogs) ? worklogs : [];

  return {
    registry: {
      total: registryItems.length,
      byRole: summarizeCounts(registryItems, "role"),
      byActive: summarizeCounts(registryItems, "is_active")
    },
    worklogs: {
      total: worklogItems.length,
      byStatus: summarizeCounts(worklogItems, "status")
    }
  };
}
