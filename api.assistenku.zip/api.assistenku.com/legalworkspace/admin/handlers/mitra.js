// admin/handlers/mitra.js
import { adminActivateMitra } from "../legacy/adminHandlers.js";

export async function handleMitraActivate({ body, user }) {
  return adminActivateMitra({ uid: body?.uid }, user);
}
