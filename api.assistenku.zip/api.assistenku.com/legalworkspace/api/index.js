// api/index.js
import { applyCors, handleOptions } from "../shared/http/cors.js";
import { parseJsonBody } from "../shared/http/body.js";
import { ok, fail } from "../shared/http/respond.js";
import { verifyIdTokenFromRequest } from "../shared/auth/firebaseAdmin.js";
import { requireRole } from "../src/middleware/role.js";
import { normalizeError } from "../src/utils/errors.js";

import { handleWhoAmI, handleRequestLinkRegistry } from "../app/handlers/auth.js";
import { handleCustomerCreateOrder } from "../app/handlers/orders.js";
import { mitraAcceptJob, mitraMe } from "../mitra/handlers/mitraHandlers.js";
import { handleRegisterDoc } from "../legalworkspace/handlers/registerDoc.js";

import {
  handleEvidenceAttach,
  handleEvidenceUploadUrl,
  handleMitraWorklogsList,
  handleWorklogCreateOrUpdate,
  handleWorklogLock,
  handleWorklogSubmit
} from "../mitra/handlers/worklogHandlers.js";

import { handleEvidenceViewUrl } from "../src/handlers/evidenceHandlers.js";

export default async function handler(req, res) {
  applyCors(req, res);
  if (req.method === "OPTIONS") return handleOptions(req, res);

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const path = url.pathname;

  try {
    const body = await parseJsonBody(req);

    if (req.method === "POST" && path === "/api/auth/request-link") {
      const data = await handleRequestLinkRegistry({ body });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/auth/whoami") {
      const user = await verifyIdTokenFromRequest(req);
      const data = await handleWhoAmI({ user });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/customer/orders/create") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["CUSTOMER"]);
      const data = await handleCustomerCreateOrder({ body, user });
      return ok(res, data, 201);
    }

    if (req.method === "POST" && path === "/api/mitra/me") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await mitraMe(user.uid);
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/mitra/jobs/accept") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await mitraAcceptJob({ orderId: body?.orderId }, user);
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/mitra/worklogs/create-or-update") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await handleWorklogCreateOrUpdate({ body, user });
      return ok(res, data);
    }

    if (req.method === "GET" && path === "/api/mitra/worklogs") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const docNumber = url.searchParams.get("docNumber");
      const data = await handleMitraWorklogsList({ user, docNumber });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/mitra/worklogs/evidence/upload-url") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await handleEvidenceUploadUrl({ body, user });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/mitra/worklogs/evidence/attach") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await handleEvidenceAttach({ body, user });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/mitra/worklogs/submit") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await handleWorklogSubmit({ body, user });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/mitra/worklogs/lock") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await handleWorklogLock({ body, user });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/legal/docs/register") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["ADMIN"]);
      const data = await handleRegisterDoc({
        body,
        user,
        adminCode: req.headers["x-admin-code"]
      });
      return ok(res, data);
    }

    if (req.method === "GET" && path === "/api/evidence/view-url") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA", "CLIENT", "ADMIN"]);
      const objectPath = url.searchParams.get("objectPath");
      const data = await handleEvidenceViewUrl({
        objectPath,
        user,
        role: user.role,
        headers: req.headers
      });
      return ok(res, data);
    }

    return fail(res, { code: "NOT_FOUND", message: "Route not found" }, 404);
  } catch (err) {
    const { status, body } = normalizeError(err);
    return fail(res, body.error, status);
  }
}
