// api/mitra.js
import { applyCors, handleOptions } from "../shared/http/cors.js";
import { parseJsonBody } from "../shared/http/body.js";
import { ok, fail } from "../shared/http/respond.js";
import { verifyIdTokenFromRequest } from "../shared/auth/firebaseAdmin.js";
import { requireRole } from "../src/middleware/role.js";
import { normalizeError } from "../src/utils/errors.js";
import { mitraAcceptJob, mitraMe } from "../mitra/handlers/mitraHandlers.js";

export default async function handler(req, res) {
  applyCors(req, res);
  if (req.method === "OPTIONS") return handleOptions(req, res);

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const path = url.pathname;

  try {
    const body = await parseJsonBody(req);

    if (req.method === "POST" && path === "/api/mitra/me") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await mitraMe(user.uid);
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/mitra/jobs/accept") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["MITRA"]);
      const data = await mitraAcceptJob(
        { orderId: body?.orderId },
        user
      );
      return ok(res, data);
    }

    return fail(res, { code: "NOT_FOUND", message: "Route not found" }, 404);
  } catch (err) {
    const { status, body } = normalizeError(err);
    return fail(res, body.error, status);
  }
}
