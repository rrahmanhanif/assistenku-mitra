import { applyCors, handleOptions } from '../../src/middleware/cors.js';
import { ok, fail } from '../../src/utils/json.js';
import { normalizeError, ApiError } from '../../src/utils/errors.js';
import { getSupabase } from '../../src/db/supabase.js';

function getBearerToken(req) {
  const header = req.headers.authorization || '';
  return header.startsWith('Bearer ') ? header.slice(7) : null;
}

function assertCronSecret(req) {
  const expected = process.env.CRON_SECRET;
  if (!expected) {
    throw new ApiError(
      'CRON_SECRET_NOT_CONFIGURED',
      500,
      'CRON_SECRET is missing. Configure it in environment variables.'
    );
  }

  const viaQuery = (() => {
    try {
      const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
      return url.searchParams.get('secret');
    } catch {
      return null;
    }
  })();

  const viaHeader = getBearerToken(req);
  const provided = viaHeader || viaQuery;

  if (!provided || provided !== expected) {
    throw new ApiError('UNAUTHORIZED', 401, 'Invalid keepalive secret');
  }
}

export default async function handler(req, res) {
  applyCors(req, res);
  if (req.method === 'OPTIONS') return handleOptions(req, res);

  try {
    if (req.method !== 'GET') {
      return fail(res, { code: 'METHOD_NOT_ALLOWED', message: 'Use GET' }, 405);
    }

    assertCronSecret(req);

    // Query ringan Supabase agar tidak idle
    const client = getSupabase();
    const ping = await client.from('audit_log').select('id').limit(1);

    if (ping.error) {
      throw new ApiError('SUPABASE_PING_FAILED', 502, 'Supabase keepalive failed', ping.error.message);
    }

    return ok(res, { ok: true, ts: new Date().toISOString() });
  } catch (err) {
    const { status, body } = normalizeError(err);
    return fail(res, body.error, status);
  }
}
