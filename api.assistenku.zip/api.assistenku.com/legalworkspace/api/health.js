import { applyCors, handleOptions } from '../src/middleware/cors.js';
import { ok, fail } from '../src/utils/json.js';
import { normalizeError } from '../src/utils/errors.js';
import { getSupabase } from '../src/db/supabase.js';

export default async function handler(req, res) {
  applyCors(req, res);
  if (req.method === 'OPTIONS') return handleOptions(req, res);

  try {
    if (req.method !== 'GET') {
      return fail(res, { code: 'METHOD_NOT_ALLOWED', message: 'Use GET' }, 405);
    }

    // Query ringan untuk memastikan Supabase reachable
    const client = getSupabase();
    const { data, error } = await client.rpc('now'); // jika tidak ada rpc 'now', fallback di bawah
    if (error) {
      // fallback: query audit_log minimal (tidak insert)
      const ping = await client.from('audit_log').select('id').limit(1);
      if (ping.error) {
        return ok(res, {
          service: 'assistenku-api',
          ts: new Date().toISOString(),
          supabase: false,
          note: 'Supabase ping failed',
          details: ping.error.message
        });
      }
    }

    return ok(res, {
      service: 'assistenku-api',
      ts: new Date().toISOString(),
      supabase: true
    });
  } catch (err) {
    const { status, body } = normalizeError(err);
    return fail(res, body.error, status);
  }
}
