// api/admin.js
import { applyCors, handleOptions } from "../shared/http/cors.js";
import { parseJsonBody } from "../shared/http/body.js";
import { ok, fail } from "../shared/http/respond.js";
import { verifyIdTokenFromRequest } from "../shared/auth/firebaseAdmin.js";
import { requireRole } from "../src/middleware/role.js";
import { requireAdminCode } from "../src/middleware/adminCode.js";
import { normalizeError } from "../src/utils/errors.js";
import { handleMitraActivate } from "../admin/handlers/mitra.js";
import { handleOrderAssign } from "../admin/handlers/orders.js";
import { handleLedgerOverview } from "../admin/handlers/ledger.js";

export default async function handler(req, res) {
  applyCors(req, res);
  if (req.method === "OPTIONS") return handleOptions(req, res);

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const path = url.pathname;

  try {
    const body = await parseJsonBody(req);
    const user = await verifyIdTokenFromRequest(req);

    user.role = await requireRole(user, ["ADMIN"]);

    // Admin code check untuk semua /api/admin/*
    requireAdminCode(req);

    if (req.method === "POST" && path === "/api/admin/mitra/activate") {
      const data = await handleMitraActivate({ body, user });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/admin/orders/assign") {
      const data = await handleOrderAssign({ body, user });
      return ok(res, data);
    }

    if (req.method === "GET" && path === "/api/admin/ledger/overview") {
      const data = await handleLedgerOverview();
      return ok(res, data);
    }

    return fail(res, { code: "NOT_FOUND", message: "Route not found" }, 404);
  } catch (err) {
    const { status, body } = normalizeError(err);
    return fail(res, body.error, status);
  }
}
