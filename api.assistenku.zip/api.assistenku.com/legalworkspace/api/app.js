// api/app.js
import { applyCors, handleOptions } from "../shared/http/cors.js";
import { parseJsonBody } from "../shared/http/body.js";
import { ok, fail } from "../shared/http/respond.js";
import { verifyIdTokenFromRequest } from "../shared/auth/firebaseAdmin.js";
import { requireRole } from "../src/middleware/role.js";
import { normalizeError } from "../src/utils/errors.js";
import { handleWhoAmI, handleRequestLinkRegistry } from "../app/handlers/auth.js";
import { handleCustomerCreateOrder } from "../app/handlers/orders.js";

export default async function handler(req, res) {
  applyCors(req, res);
  if (req.method === "OPTIONS") return handleOptions(req, res);

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const path = url.pathname;

  try {
    const body = await parseJsonBody(req);

    if (req.method === "POST" && path === "/api/app/auth/request-link") {
      const data = await handleRequestLinkRegistry({ body });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/app/auth/whoami") {
      const user = await verifyIdTokenFromRequest(req);
      const data = await handleWhoAmI({ user });
      return ok(res, data);
    }

    if (req.method === "POST" && path === "/api/app/customer/orders/create") {
      const user = await verifyIdTokenFromRequest(req);
      user.role = await requireRole(user, ["CUSTOMER"]);
      const data = await handleCustomerCreateOrder({ body, user });
      return ok(res, data, 201);
    }

    return fail(res, { code: "NOT_FOUND", message: "Route not found" }, 404);
  } catch (err) {
    const { status, body } = normalizeError(err);
    return fail(res, body.error, status);
  }
}
