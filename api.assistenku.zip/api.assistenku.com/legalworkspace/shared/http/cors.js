// shared/http/cors.js

const ALLOWED_ORIGINS = new Set([
  "https://admin.assistenku.com",
  "https://mitra.assistenku.com",
  "https://app.assistenku.com",
  "https://legalworkspace.assistenku.com",
  "http://localhost:3000",
  "http://localhost:5173",
]);

const ALLOWED_HEADERS = [
  "Content-Type",
  "Authorization",
  "X-Admin-Code",
  "X-Customer-Id",
  "X-Mitra-Id",
  "Idempotency-Key",
  "X-Requested-With",
];

export function applyCors(req, res) {
  const origin = req.headers.origin;

  if (origin && ALLOWED_ORIGINS.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }

  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", ALLOWED_HEADERS.join(", "));
  res.setHeader("Access-Control-Max-Age", "86400");
}

export function handleOptions(req, res) {
  applyCors(req, res);
  res.statusCode = 204;
  res.end();
}
