// shared/http/respond.js

export function sendJson(res, statusCode, payload) {
  res.statusCode = statusCode;
  res.setHeader("Content-Type", "application/json");
  res.end(JSON.stringify(payload));
}

export function ok(res, data = null, statusCode = 200) {
  sendJson(res, statusCode, {
    ok: true,
    data,
  });
}

export function fail(res, error, statusCode = 400) {
  sendJson(res, statusCode, {
    ok: false,
    error,
  });
}
