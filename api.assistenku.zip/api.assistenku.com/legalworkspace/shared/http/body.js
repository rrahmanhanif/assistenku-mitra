// shared/http/body.js
import { ApiError } from "../../src/utils/errors.js";

export async function parseBodyRaw(req) {
  const chunks = [];

  for await (const chunk of req) {
    chunks.push(chunk);
  }

  return Buffer.concat(chunks);
}

export async function parseJsonBody(req) {
  const raw = await parseBodyRaw(req);

  if (!raw.length) return {};

  try {
    return JSON.parse(raw.toString("utf8"));
  } catch (err) {
    throw new ApiError(
      "INVALID_JSON",
      400,
      "Invalid JSON body",
      err.message
    );
  }
}
