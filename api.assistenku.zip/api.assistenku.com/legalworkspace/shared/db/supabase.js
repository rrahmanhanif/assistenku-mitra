// shared/db/supabase.js
import { createClient } from "@supabase/supabase-js";
import { ApiError } from "../../src/utils/errors.js";

let supabaseAdmin = null;
let supabaseAnon = null;

export function getSupabaseAdmin() {
  if (supabaseAdmin) return supabaseAdmin;

  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new ApiError(
      "SUPABASE_NOT_CONFIGURED",
      500,
      "Supabase environment variables are missing. Configure SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY."
    );
  }

  supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });

  return supabaseAdmin;
}

export function getSupabaseAnon() {
  if (supabaseAnon) return supabaseAnon;

  const { SUPABASE_URL, SUPABASE_ANON_KEY } = process.env;

  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    throw new ApiError(
      "SUPABASE_ANON_NOT_CONFIGURED",
      500,
      "Supabase anon environment variables are missing. Configure SUPABASE_URL and SUPABASE_ANON_KEY."
    );
  }

  supabaseAnon = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });

  return supabaseAnon;
}
