import { ApiError } from "../../src/utils/errors.js";

function getSupabaseConfig() {
  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new ApiError(
      "SUPABASE_NOT_CONFIGURED",
      500,
      "Supabase environment variables are missing. Configure SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY."
    );
  }

  return { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY };
}

function buildHeaders(customHeaders = {}) {
  const { SUPABASE_SERVICE_ROLE_KEY } = getSupabaseConfig();

  return {
    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    ...customHeaders
  };
}

function formatFilterValue(value) {
  if (value === null || value === undefined) {
    return "null";
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  return String(value);
}

function applyFilters(params, filters = []) {
  filters.forEach(({ column, operator = "eq", value }) => {
    if (!column) return;

    if (operator === "in" && Array.isArray(value)) {
      const values = value.map((entry) => `"${String(entry)}"`).join(",");
      params.append(column, `in.(${values})`);
      return;
    }

    params.append(column, `${operator}.${formatFilterValue(value)}`);
  });
}

function buildRestUrl({ table, select, filters, query } = {}) {
  const { SUPABASE_URL } = getSupabaseConfig();
  const url = new URL(`${SUPABASE_URL.replace(/\/$/, "")}/rest/v1/${table}`);

  if (select) {
    url.searchParams.set("select", select);
  }

  applyFilters(url.searchParams, filters);

  if (query) {
    Object.entries(query).forEach(([key, value]) => {
      if (value === undefined || value === null || value === "") return;
      url.searchParams.set(key, value);
    });
  }

  return url;
}

async function parseResponse(response) {
  const text = await response.text();
  if (!text) return null;

  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

export async function supabaseRestRequest({
  table,
  method = "GET",
  select,
  filters,
  query,
  body,
  headers,
  single = false
} = {}) {
  if (!table) {
    throw new ApiError("SUPABASE_REQUEST_INVALID", 500, "Missing table name");
  }

  const url = buildRestUrl({ table, select, filters, query });

  const requestHeaders = buildHeaders({
    "Content-Type": "application/json",
    ...headers
  });

  if (single) {
    requestHeaders.Accept = "application/vnd.pgrst.object+json";
  }

  const response = await fetch(url, {
    method,
    headers: requestHeaders,
    body: body ? JSON.stringify(body) : undefined
  });

  const data = await parseResponse(response);

  if (!response.ok) {
    throw new ApiError(
      "SUPABASE_REQUEST_FAILED",
      response.status,
      "Supabase request failed",
      data
    );
  }

  return data;
}

export async function supabaseRestUpsert({
  table,
  record,
  onConflict,
  select = "*"
} = {}) {
  return supabaseRestRequest({
    table,
    method: "POST",
    select,
    query: onConflict ? { on_conflict: onConflict } : undefined,
    headers: {
      Prefer: "resolution=merge-duplicates,return=representation"
    },
    body: record
  });
}

export async function supabaseRestInsert({ table, record, select = "*" } = {}) {
  return supabaseRestRequest({
    table,
    method: "POST",
    select,
    headers: {
      Prefer: "return=representation"
    },
    body: record
  });
}

export async function supabaseRestUpdate({
  table,
  record,
  filters,
  select = "*"
} = {}) {
  return supabaseRestRequest({
    table,
    method: "PATCH",
    select,
    filters,
    headers: {
      Prefer: "return=representation"
    },
    body: record
  });
}
