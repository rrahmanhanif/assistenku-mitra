import { ApiError } from "../../src/utils/errors.js";

function getSupabaseConfig() {
  const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new ApiError(
      "SUPABASE_NOT_CONFIGURED",
      500,
      "Supabase environment variables are missing. Configure SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY."
    );
  }

  return { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY };
}

function buildStorageHeaders() {
  const { SUPABASE_SERVICE_ROLE_KEY } = getSupabaseConfig();

  return {
    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    "Content-Type": "application/json"
  };
}

function encodeStoragePath(objectPath) {
  return objectPath
    .split("/")
    .map((segment) => encodeURIComponent(segment))
    .join("/");
}

async function parseStorageResponse(response) {
  const text = await response.text();
  if (!text) return null;

  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

async function requestStorageSignedUrl(endpoint, payload) {
  const { SUPABASE_URL } = getSupabaseConfig();
  const url = `${SUPABASE_URL.replace(/\/$/, "")}${endpoint}`;

  const response = await fetch(url, {
    method: "POST",
    headers: buildStorageHeaders(),
    body: JSON.stringify(payload)
  });

  const data = await parseStorageResponse(response);

  if (!response.ok) {
    const message =
      response.status === 404
        ? "Storage bucket or object not found"
        : "Failed to create signed URL";
    throw new ApiError("STORAGE_SIGNED_URL_FAILED", response.status, message, data);
  }

  return data;
}

export async function createSignedUploadUrl(bucket, objectPath, ttlSeconds) {
  if (!bucket || !objectPath) {
    throw new ApiError(
      "STORAGE_SIGNED_URL_INVALID",
      400,
      "Bucket and object path are required"
    );
  }

  const encodedPath = encodeStoragePath(objectPath);
  const data = await requestStorageSignedUrl(
    `/storage/v1/object/upload/sign/${bucket}/${encodedPath}`,
    { expiresIn: ttlSeconds }
  );

  const signedUrl = data?.signedUrl || data?.signedURL;

  if (!signedUrl) {
    throw new ApiError(
      "STORAGE_SIGNED_URL_FAILED",
      500,
      "Supabase storage did not return a signed upload URL",
      data
    );
  }

  return { signedUrl, expiresIn: ttlSeconds };
}

export async function createSignedViewUrl(bucket, objectPath, ttlSeconds) {
  if (!bucket || !objectPath) {
    throw new ApiError(
      "STORAGE_SIGNED_URL_INVALID",
      400,
      "Bucket and object path are required"
    );
  }

  const encodedPath = encodeStoragePath(objectPath);
  const data = await requestStorageSignedUrl(
    `/storage/v1/object/sign/${bucket}/${encodedPath}`,
    { expiresIn: ttlSeconds }
  );

  const signedUrl = data?.signedUrl || data?.signedURL;

  if (!signedUrl) {
    throw new ApiError(
      "STORAGE_SIGNED_URL_FAILED",
      500,
      "Supabase storage did not return a signed view URL",
      data
    );
  }

  return { signedUrl, expiresIn: ttlSeconds };
}
