// shared/auth/firebaseAdmin.js
import * as admin from "firebase-admin";
import { ApiError } from "../../src/utils/errors.js";

let firebaseInitialized = false;

function initFirebase() {
  if (firebaseInitialized) return;

  const {
    FIREBASE_PROJECT_ID,
    FIREBASE_CLIENT_EMAIL,
    FIREBASE_PRIVATE_KEY,
  } = process.env;

  // Validasi env
  if (
    !FIREBASE_PROJECT_ID ||
    !FIREBASE_CLIENT_EMAIL ||
    !FIREBASE_PRIVATE_KEY
  ) {
    throw new ApiError(
      "FIREBASE_NOT_CONFIGURED",
      500,
      "Firebase env missing. Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY"
    );
  }

  // Wajib replace newline
  const privateKey = FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n");

  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: FIREBASE_PROJECT_ID, // assitenku-8ef85
      clientEmail: FIREBASE_CLIENT_EMAIL,
      privateKey,
    }),
  });

  firebaseInitialized = true;
}

export function getBearerToken(req) {
  const header = req.headers.authorization || "";
  return header.startsWith("Bearer ") ? header.slice(7) : null;
}

export async function verifyIdTokenFromRequest(req) {
  const token = getBearerToken(req);

  if (!token) {
    throw new ApiError("UNAUTHORIZED", 401, "Missing Authorization header");
  }

  initFirebase();

  const decoded = await admin.auth().verifyIdToken(token);

  const roleClaim =
    decoded.role ||
    decoded.role?.toUpperCase?.() ||
    decoded["https://hasura.io/jwt/claims"]?.["x-hasura-default-role"] ||
    null;

  return {
    uid: decoded.uid,
    email: decoded.email,
    role: roleClaim,
    claims: decoded,
  };
}
