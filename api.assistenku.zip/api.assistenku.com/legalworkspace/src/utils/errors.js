export class ApiError extends Error {
  constructor(code, status = 400, message = 'Request failed', details) {
    super(message);
    this.code = code;
    this.status = status;
    this.details = details;
  }
}

export function normalizeError(err) {
  if (err instanceof ApiError) {
    return {
      status: err.status,
      body: {
        ok: false,
        error: {
          code: err.code,
          message: err.message,
          details: err.details
        }
      }
    };
  }

  return {
    status: 500,
    body: {
      ok: false,
      error: {
        code: 'INTERNAL_ERROR',
        message: 'Unexpected error',
        details: process.env.NODE_ENV === 'development' ? String(err) : undefined
      }
    }
  };
}
