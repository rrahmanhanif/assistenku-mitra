import * as admin from 'firebase-admin';
import { ApiError } from '../utils/errors.js';

let firebaseInitialized = false;

function initFirebase() {
  if (firebaseInitialized) return;

  const {
    FIREBASE_PROJECT_ID,
    FIREBASE_CLIENT_EMAIL,
    FIREBASE_PRIVATE_KEY
  } = process.env;

  if (!FIREBASE_PROJECT_ID || !FIREBASE_CLIENT_EMAIL || !FIREBASE_PRIVATE_KEY) {
    throw new ApiError(
      'FIREBASE_NOT_CONFIGURED',
      500,
      'Firebase environment variables are missing. Protected endpoints are disabled.'
    );
  }

  const privateKey = FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n');

  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: FIREBASE_PROJECT_ID,
      clientEmail: FIREBASE_CLIENT_EMAIL,
      privateKey
    })
  });

  firebaseInitialized = true;
}

export async function verifyToken(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    throw new ApiError('UNAUTHORIZED', 401, 'Missing Authorization header');
  }

  initFirebase();

  const decoded = await admin.auth().verifyIdToken(token);

  const roleClaim =
    decoded.role ||
    decoded.role?.toUpperCase?.() ||
    decoded['https://hasura.io/jwt/claims']?.['x-hasura-default-role'] ||
    null;

  return {
    uid: decoded.uid,
    email: decoded.email,
    role: roleClaim,
    claims: decoded
  };
}

export function getTokenlessUser(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return null;
  return { token };
}
