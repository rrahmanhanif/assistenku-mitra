import { ApiError } from '../utils/errors.js';
import { getSupabase } from '../db/supabase.js';

function parseAdminEmails() {
  const raw = process.env.ADMIN_EMAILS || '';
  return raw
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

async function fetchDbRole(client, uid) {
  const { data, error } = await client
    .from('profiles')
    .select('role')
    .eq('uid', uid)
    .single();

  if (error && error.code !== 'PGRST116') {
    throw new ApiError(
      'PROFILE_FETCH_FAILED',
      500,
      'Failed to fetch profile role',
      error.message
    );
  }

  return data?.role || null;
}

export async function resolveRole(user, { client } = {}) {
  if (!user) {
    throw new ApiError('UNAUTHORIZED', 401, 'Missing user');
  }

  const claimRole = user?.claims?.role || user?.role;
  if (typeof claimRole === 'string' && claimRole.trim()) {
    return claimRole.toUpperCase();
  }

  const supabase = client || getSupabase();
  if (user.uid) {
    const dbRole = await fetchDbRole(supabase, user.uid);
    if (dbRole) return dbRole;
  }

  const email = user?.email?.toLowerCase();
  if (email && parseAdminEmails().includes(email)) {
    return 'ADMIN';
  }

  return 'UNKNOWN';
}

export async function requireRole(user, allowedRoles, options = {}) {
  const role = await resolveRole(user, options);
  if (!allowedRoles.includes(role)) {
    throw new ApiError(
      'FORBIDDEN',
      403,
      `Requires role: ${allowedRoles.join(',')}`
    );
  }
  return role;
}

export function requireMitraActive(mitraProfile) {
  if (!mitraProfile) {
    throw new ApiError('NOT_FOUND', 404, 'Mitra profile not found');
  }
  if (mitraProfile.status !== 'ACTIVE') {
    throw new ApiError('MITRA_NOT_ACTIVE', 403, 'Mitra is not active');
  }
}
