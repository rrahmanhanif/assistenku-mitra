import { ApiError } from "../utils/errors.js";

export function requireAdminCode(req) {
  const expected = process.env.ADMIN_CODE || "309309";
  const got = req.headers["x-admin-code"];

  if (!got || String(got) !== String(expected)) {
    throw new ApiError("ADMIN_CODE_INVALID", 403, "Admin code invalid");
  }
}
