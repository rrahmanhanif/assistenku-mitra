import { ApiError } from "../utils/errors.js";
import { createSignedViewUrl } from "../../shared/supabase/storage.js";
import { supabaseRestInsert, supabaseRestRequest } from "../../shared/supabase/client.js";

function getEvidenceBucket() {
  return process.env.EVIDENCE_BUCKET || "legal-evidence";
}

function getSignedUrlTtl() {
  const ttl = Number(process.env.SIGNED_URL_TTL_SECONDS || 3600);
  return Number.isFinite(ttl) && ttl > 0 ? ttl : 3600;
}

function parseAdminEmails() {
  const raw = process.env.ADMIN_EMAILS || "";
  return raw
    .split(",")
    .map((entry) => entry.trim().toLowerCase())
    .filter(Boolean);
}

function parseObjectPath(objectPath) {
  if (!objectPath || typeof objectPath !== "string") {
    throw new ApiError("VALIDATION_ERROR", 400, "objectPath is required");
  }

  const parts = objectPath.split("/");
  if (parts.length < 4 || parts[0] !== "evidence") {
    throw new ApiError(
      "INVALID_OBJECT_PATH",
      400,
      "objectPath must follow evidence/{docType}/{docNumber}/... convention"
    );
  }

  return {
    docType: parts[1],
    docNumber: parts[2]
  };
}

async function isMitraAuthorized({ email, objectPath, docNumber }) {
  const worklogs = await supabaseRestRequest({
    table: "worklogs",
    select: "id, evidence, doc_number",
    filters: [
      { column: "mitra_email", operator: "eq", value: email },
      { column: "doc_number", operator: "eq", value: docNumber }
    ]
  });

  return (worklogs || []).some((worklog) =>
    Array.isArray(worklog?.evidence)
      ? worklog.evidence.some((item) => item?.objectPath === objectPath)
      : false
  );
}

async function isClientAuthorized({ email, docNumber }) {
  const registry = await supabaseRestRequest({
    table: "legal_registry",
    select: "id",
    filters: [
      { column: "doc_number", operator: "eq", value: docNumber },
      { column: "role", operator: "eq", value: "CLIENT" },
      { column: "email", operator: "eq", value: email },
      { column: "is_active", operator: "eq", value: true }
    ]
  });

  return Array.isArray(registry) && registry.length > 0;
}

function requireAdminCode(headers) {
  const adminCode = process.env.ADMIN_CODE || "309309";
  const provided = headers?.["x-admin-code"];

  if (!provided || String(provided) !== String(adminCode)) {
    throw new ApiError("FORBIDDEN", 403, "Invalid admin code");
  }
}

export async function handleEvidenceViewUrl({ objectPath, user, role, headers } = {}) {
  const email = user?.email?.toLowerCase();
  if (!email) {
    throw new ApiError("UNAUTHORIZED", 401, "User email is missing");
  }

  const { docNumber } = parseObjectPath(objectPath);

  if (role === "ADMIN") {
    const adminEmails = parseAdminEmails();
    if (adminEmails.length && !adminEmails.includes(email)) {
      throw new ApiError("FORBIDDEN", 403, "Admin email is not allowed");
    }
    requireAdminCode(headers);
  } else if (role === "MITRA") {
    const ok = await isMitraAuthorized({ email, objectPath, docNumber });
    if (!ok) {
      throw new ApiError("FORBIDDEN", 403, "Mitra does not have access to this evidence");
    }
  } else if (role === "CLIENT") {
    const ok = await isClientAuthorized({ email, docNumber });
    if (!ok) {
      throw new ApiError("FORBIDDEN", 403, "Client does not have access to this evidence");
    }
  } else {
    throw new ApiError("FORBIDDEN", 403, "Access denied");
  }

  const bucket = getEvidenceBucket();
  const expiresIn = getSignedUrlTtl();
  const { signedUrl } = await createSignedViewUrl(bucket, objectPath, expiresIn);

  await supabaseRestInsert({
    table: "audit_log",
    record: {
      actor_uid: user.uid,
      actor_role: role,
      action: "EVIDENCE_VIEW_URL_ISSUED",
      entity_type: "worklogs",
      entity_id: null,
      payload: { objectPath }
    }
  });

  return { signedUrl, expiresIn };
}
