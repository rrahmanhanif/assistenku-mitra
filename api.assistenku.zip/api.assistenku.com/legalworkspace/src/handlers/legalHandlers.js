import { legalRegisterDoc } from './adminHandlers.js';

export { legalRegisterDoc };
