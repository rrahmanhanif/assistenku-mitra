import { getSupabaseAdmin } from "../../shared/db/supabase.js";
import { ApiError } from "../utils/errors.js";

export function getSupabase() {
  return getSupabaseAdmin();
}

export async function insertAudit({
  actorUid,
  actorRole,
  action,
  entityType,
  entityId,
  payload,
}) {
  const client = getSupabase();

  const { error } = await client.from("audit_log").insert({
    actor_uid: actorUid,
    actor_role: actorRole,
    action,
    entity_type: entityType,
    entity_id: entityId,
    payload,
  });

  if (error) {
    throw new ApiError(
      "AUDIT_FAILED",
      500,
      "Failed to write audit log",
      error.message
    );
  }
}
