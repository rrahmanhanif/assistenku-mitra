import { getSupabase, insertAudit } from "../../src/db/supabase.js";
import { ApiError } from "../../src/utils/errors.js";
import { requireMitraActive } from "../../src/middleware/role.js";

export async function mitraMe(uid) {
  const client = getSupabase();

  const { data, error } = await client
    .from("mitra_profiles")
    .select("*")
    .eq("uid", uid)
    .single();

  if (error) {
    throw new ApiError(
      "MITRA_FETCH_FAILED",
      500,
      "Failed to fetch mitra profile",
      error.message
    );
  }

  return data;
}

export async function mitraAcceptJob({ orderId }, actor) {
  if (!orderId) {
    throw new ApiError("VALIDATION_ERROR", 400, "orderId is required");
  }

  const client = getSupabase();

  const { data: mitraProfile, error: mitraError } = await client
    .from("mitra_profiles")
    .select("*")
    .eq("uid", actor.uid)
    .single();

  if (mitraError) {
    throw new ApiError(
      "MITRA_FETCH_FAILED",
      500,
      "Failed to fetch mitra profile",
      mitraError.message
    );
  }

  requireMitraActive(mitraProfile);

  const { data, error } = await client
    .from("orders")
    .update({
      mitra_uid: actor.uid,
      status: "MITRA_ACCEPTED",
    })
    .eq("id", orderId)
    .select()
    .single();

  if (error) {
    throw new ApiError(
      "ORDER_ACCEPT_FAILED",
      500,
      "Failed to accept order",
      error.message
    );
  }

  await insertAudit({
    actorUid: actor.uid,
    actorRole: "MITRA",
    action: "MITRA_ACCEPT_JOB",
    entityType: "orders",
    entityId: orderId,
    payload: {},
  });

  return data;
}
