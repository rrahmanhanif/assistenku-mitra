import { ApiError } from "../../src/utils/errors.js";
import {
  supabaseRestInsert,
  supabaseRestRequest,
  supabaseRestUpdate,
  supabaseRestUpsert
} from "../../shared/supabase/client.js";
import { createSignedUploadUrl } from "../../shared/supabase/storage.js";

const LOCKED_STATUSES = new Set(["LOCKED_BY_SYSTEM", "FINAL"]);

function getEvidenceBucket() {
  return process.env.EVIDENCE_BUCKET || "legal-evidence";
}

function getSignedUrlTtl() {
  const ttl = Number(process.env.SIGNED_URL_TTL_SECONDS || 3600);
  return Number.isFinite(ttl) && ttl > 0 ? ttl : 3600;
}

function normalizeFilename(filename) {
  if (!filename || typeof filename !== "string") {
    throw new ApiError("VALIDATION_ERROR", 400, "filename is required");
  }

  const normalized = filename
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9._-]/g, "");

  const safe = normalized || "file";
  return safe.slice(0, 120);
}

function buildObjectPath({ docType, docNumber, worklogId, filename }) {
  const safeFilename = normalizeFilename(filename);
  return `evidence/${docType}/${docNumber}/${worklogId}/${safeFilename}`;
}

function requireMitraEmail(user) {
  const email = user?.email?.toLowerCase();
  if (!email) {
    throw new ApiError("UNAUTHORIZED", 401, "User email is missing");
  }
  return email;
}

function requireWorklogInputs({ docType, docNumber, date }) {
  if (!docType || !docNumber || !date) {
    throw new ApiError(
      "VALIDATION_ERROR",
      400,
      "docType, docNumber, and date are required"
    );
  }
}

async function fetchWorklog({ mitraEmail, docNumber, date }) {
  const data = await supabaseRestRequest({
    table: "worklogs",
    select: "*",
    filters: [
      { column: "mitra_email", operator: "eq", value: mitraEmail },
      { column: "doc_number", operator: "eq", value: docNumber },
      { column: "date", operator: "eq", value: date }
    ]
  });

  return Array.isArray(data) ? data[0] : null;
}

async function insertAudit({
  actorUid,
  actorRole,
  action,
  entityType,
  entityId,
  payload
}) {
  await supabaseRestInsert({
    table: "audit_log",
    record: {
      actor_uid: actorUid,
      actor_role: actorRole,
      action,
      entity_type: entityType,
      entity_id: entityId,
      payload
    }
  });
}

export async function handleWorklogCreateOrUpdate({ body, user }) {
  const mitraEmail = requireMitraEmail(user);
  const docType = body?.docType;
  const docNumber = body?.docNumber;
  const date = body?.date;

  requireWorklogInputs({ docType, docNumber, date });

  const existing = await fetchWorklog({ mitraEmail, docNumber, date });

  if (existing && LOCKED_STATUSES.has(existing.status)) {
    throw new ApiError(
      "WORKLOG_LOCKED",
      409,
      "Worklog is locked and cannot be updated"
    );
  }

  if (!existing) {
    const created = await supabaseRestUpsert({
      table: "worklogs",
      record: {
        mitra_email: mitraEmail,
        doc_type: docType,
        doc_number: docNumber,
        date,
        hours: body?.hours ?? null,
        notes: body?.notes ?? null,
        status: "DRAFT"
      },
      onConflict: "mitra_email,doc_number,date"
    });

    const worklog = Array.isArray(created) ? created[0] : created;

    await insertAudit({
      actorUid: user.uid,
      actorRole: user.role,
      action: "WORKLOG_UPSERT_DRAFT",
      entityType: "worklogs",
      entityId: worklog?.id,
      payload: { docNumber, date }
    });

    return { worklog };
  }

  const updated = await supabaseRestUpdate({
    table: "worklogs",
    record: {
      doc_type: docType,
      doc_number: docNumber,
      date,
      hours: body?.hours ?? null,
      notes: body?.notes ?? null
    },
    filters: [
      { column: "mitra_email", operator: "eq", value: mitraEmail },
      { column: "doc_number", operator: "eq", value: docNumber },
      { column: "date", operator: "eq", value: date }
    ]
  });

  const worklog = Array.isArray(updated) ? updated[0] : updated;

  await insertAudit({
    actorUid: user.uid,
    actorRole: user.role,
    action: "WORKLOG_UPSERT_DRAFT",
    entityType: "worklogs",
    entityId: worklog?.id,
    payload: { docNumber, date }
  });

  return { worklog };
}

export async function handleMitraWorklogsList({ user, docNumber }) {
  const mitraEmail = requireMitraEmail(user);

  const filters = [{ column: "mitra_email", operator: "eq", value: mitraEmail }];

  if (docNumber) {
    filters.push({ column: "doc_number", operator: "eq", value: docNumber });
  }

  const items = await supabaseRestRequest({
    table: "worklogs",
    select: "*",
    filters
  });

  return { items: Array.isArray(items) ? items : [] };
}

export async function handleEvidenceUploadUrl({ body, user }) {
  const mitraEmail = requireMitraEmail(user);
  const docType = body?.docType;
  const docNumber = body?.docNumber;
  const date = body?.date;
  const filename = body?.filename;
  const contentType = body?.contentType;

  requireWorklogInputs({ docType, docNumber, date });

  if (!filename || !contentType) {
    throw new ApiError(
      "VALIDATION_ERROR",
      400,
      "filename and contentType are required"
    );
  }

  let worklog = await fetchWorklog({ mitraEmail, docNumber, date });

  if (worklog && LOCKED_STATUSES.has(worklog.status)) {
    throw new ApiError(
      "WORKLOG_LOCKED",
      409,
      "Worklog is locked and cannot accept evidence"
    );
  }

  if (!worklog) {
    const created = await supabaseRestInsert({
      table: "worklogs",
      record: {
        mitra_email: mitraEmail,
        doc_type: docType,
        doc_number: docNumber,
        date,
        status: "DRAFT"
      }
    });
    worklog = Array.isArray(created) ? created[0] : created;
  }

  const objectPath = buildObjectPath({
    docType,
    docNumber,
    worklogId: worklog?.id,
    filename
  });

  const bucket = getEvidenceBucket();
  const expiresIn = getSignedUrlTtl();
  const { signedUrl } = await createSignedUploadUrl(bucket, objectPath, expiresIn);

  await insertAudit({
    actorUid: user.uid,
    actorRole: user.role,
    action: "EVIDENCE_UPLOAD_URL_ISSUED",
    entityType: "worklogs",
    entityId: worklog?.id,
    payload: {
      docNumber,
      date,
      objectPath,
      filename,
      contentType
    }
  });

  return {
    worklogId: worklog?.id,
    bucket,
    objectPath,
    signedUrl,
    expiresIn
  };
}

export async function handleEvidenceAttach({ body, user }) {
  const mitraEmail = requireMitraEmail(user);
  const docNumber = body?.docNumber;
  const date = body?.date;
  const objectPath = body?.objectPath;
  const filename = body?.filename;
  const contentType = body?.contentType;
  const size = body?.size;
  const sha256 = body?.sha256;

  if (!docNumber || !date || !objectPath || !filename || !contentType) {
    throw new ApiError(
      "VALIDATION_ERROR",
      400,
      "docNumber, date, objectPath, filename, and contentType are required"
    );
  }

  const worklog = await fetchWorklog({ mitraEmail, docNumber, date });

  if (!worklog) {
    throw new ApiError("NOT_FOUND", 404, "Worklog not found");
  }

  if (LOCKED_STATUSES.has(worklog.status)) {
    throw new ApiError(
      "WORKLOG_LOCKED",
      409,
      "Worklog is locked and cannot accept evidence"
    );
  }

  const expectedPrefix = `evidence/${worklog.doc_type}/${docNumber}/${worklog.id}/`;
  if (!objectPath.startsWith(expectedPrefix)) {
    throw new ApiError(
      "INVALID_OBJECT_PATH",
      400,
      "objectPath does not match the expected worklog evidence path"
    );
  }

  const evidence = Array.isArray(worklog.evidence) ? [...worklog.evidence] : [];
  const filtered = evidence.filter((item) => item?.objectPath !== objectPath);

  const nextEvidence = [
    ...filtered,
    {
      objectPath,
      filename,
      contentType,
      size,
      sha256: sha256 || null,
      uploadedAt: new Date().toISOString()
    }
  ];

  const updated = await supabaseRestUpdate({
    table: "worklogs",
    record: { evidence: nextEvidence },
    filters: [
      { column: "mitra_email", operator: "eq", value: mitraEmail },
      { column: "doc_number", operator: "eq", value: docNumber },
      { column: "date", operator: "eq", value: date }
    ]
  });

  const updatedWorklog = Array.isArray(updated) ? updated[0] : updated;

  await insertAudit({
    actorUid: user.uid,
    actorRole: user.role,
    action: "EVIDENCE_ATTACHED_TO_WORKLOG",
    entityType: "worklogs",
    entityId: updatedWorklog?.id,
    payload: { docNumber, date, objectPath }
  });

  return { worklog: updatedWorklog };
}

export async function handleWorklogSubmit({ body, user }) {
  const mitraEmail = requireMitraEmail(user);
  const docNumber = body?.docNumber;
  const date = body?.date;

  if (!docNumber || !date) {
    throw new ApiError("VALIDATION_ERROR", 400, "docNumber and date are required");
  }

  const worklog = await fetchWorklog({ mitraEmail, docNumber, date });

  if (!worklog) {
    throw new ApiError("NOT_FOUND", 404, "Worklog not found");
  }

  if (["SUBMITTED", "LOCKED_BY_SYSTEM", "FINAL"].includes(worklog.status)) {
    return { worklog };
  }

  const updated = await supabaseRestUpdate({
    table: "worklogs",
    record: { status: "SUBMITTED" },
    filters: [
      { column: "mitra_email", operator: "eq", value: mitraEmail },
      { column: "doc_number", operator: "eq", value: docNumber },
      { column: "date", operator: "eq", value: date }
    ]
  });

  const updatedWorklog = Array.isArray(updated) ? updated[0] : updated;

  await insertAudit({
    actorUid: user.uid,
    actorRole: user.role,
    action: "WORKLOG_SUBMITTED",
    entityType: "worklogs",
    entityId: updatedWorklog?.id,
    payload: { docNumber, date }
  });

  return { worklog: updatedWorklog };
}

export async function handleWorklogLock({ body, user }) {
  const mitraEmail = requireMitraEmail(user);
  const docNumber = body?.docNumber;
  const date = body?.date;

  if (!docNumber || !date) {
    throw new ApiError("VALIDATION_ERROR", 400, "docNumber and date are required");
  }

  const worklog = await fetchWorklog({ mitraEmail, docNumber, date });

  if (!worklog) {
    throw new ApiError("NOT_FOUND", 404, "Worklog not found");
  }

  if (worklog.status !== "SUBMITTED") {
    throw new ApiError(
      "WORKLOG_NOT_SUBMITTED",
      409,
      "Worklog must be submitted before locking"
    );
  }

  const updated = await supabaseRestUpdate({
    table: "worklogs",
    record: { status: "LOCKED_BY_SYSTEM" },
    filters: [
      { column: "mitra_email", operator: "eq", value: mitraEmail },
      { column: "doc_number", operator: "eq", value: docNumber },
      { column: "date", operator: "eq", value: date }
    ]
  });

  const updatedWorklog = Array.isArray(updated) ? updated[0] : updated;

  await insertAudit({
    actorUid: user.uid,
    actorRole: user.role,
    action: "WORKLOG_LOCKED_BY_SYSTEM",
    entityType: "worklogs",
    entityId: updatedWorklog?.id,
    payload: { docNumber, date }
  });

  return { worklog: updatedWorklog };
}
