# STRUCTURE

Berikut struktur repo final sesuai ZIP referensi.

assistenku
├── admin
│ └── api
│ ├── _lib
│ │ ├── firebaseAdmin.js
│ │ ├── session.js
│ │ └── supabaseAdmin.js
│ ├── admin
│ │ ├── auth
│ │ │ ├── logout.js
│ │ │ ├── me.js
│ │ │ └── verify.js
│ │ └── verify.js
│ ├── audit
│ │ └── search.js
│ ├── config
│ │ ├── pricing.js
│ │ └── services.js
│ ├── disputes
│ │ ├── create.js
│ │ └── resolve.js
│ ├── evidence
│ │ ├── decision.js
│ │ └── upload.js
│ ├── health
│ │ └── route.ts
│ ├── invoices
│ │ ├── generate.js
│ │ ├── list.js
│ │ └── mark-paid.js
│ ├── orders
│ │ ├── assign.js
│ │ ├── cancel.js
│ │ ├── checkin.js
│ │ ├── close.js
│ │ ├── complete.js
│ │ ├── create.js
│ │ └── list.js
│ ├── payouts
│ │ ├── approve.js
│ │ ├── mark-failed.js
│ │ ├── mark-success.js
│ │ └── request.js
│ ├── pricing
│ │ └── publish.js
│ ├── services
│ │ └── list.js
│ ├── withdraw
│ │ └── list.js
│ ├── mitraProfiles.js
│ ├── order.js
│ ├── orderApi.js
│ ├── payments.js
│ ├── payputservice.js
│ ├── role.js
│ └── services.js
├── customer
│ └── api
│ ├── chat
│ │ ├── list.js
│ │ └── send.js
│ ├── config
│ │ ├── pricing.js
│ │ └── services.js
│ ├── customer
│ │ └── me.js
│ ├── disputes
│ │ ├── create.js
│ │ └── list.js
│ ├── invoice
│ │ ├── list.js
│ │ └── mark-paid-request.js
│ ├── orders
│ │ ├── [orderId]
│ │ │ ├── evidence
│ │ │ │ └── decision.js
│ │ │ ├── payment
│ │ │ │ ├── create.js
│ │ │ │ └── proof.js
│ │ │ ├── cancel.js
│ │ │ └── index.js
│ │ ├── create.js
│ │ ├── estimate.js
│ │ └── list.js
│ ├── payment
│ │ └── list.js
│ ├── services
│ │ └── list.js
│ ├── _orderHelpers.js
│ ├── _supabaseClient.js
│ ├── _utils.js
│ ├── client.js
│ └── getServices.js
└── mitra
└── api
├── apiClient.js
├── getServices.js
├── jobs.js
├── me.js
├── orders.js
├── payouts.js
└── profile.js

legalworkspace
├── .github
│ └── workflows
│ └── keepalive.yml
├── admin
│ ├── handlers
│ │ ├── ledger.js
│ │ ├── mitra.js
│ │ └── orders.js
│ └── legacy
│ └── adminHandlers.js
├── api
│ ├── internal
│ │ └── keepalive.js
│ ├── admin.js
│ ├── app.js
│ ├── health.js
│ ├── index.js
│ ├── legalworkspace.js
│ ├── mitra.js
│ └── uploads.js
├── app
│ ├── handlers
│ │ ├── auth.js
│ │ ├── orders.js
│ │ ├── requestLink.js
│ │ └── uploads.js
│ └── legacy
│ ├── authHandlers.js
│ ├── customerHandlers.js
│ └── uploadsHandlers.js
├── legalworkspace
│ └── handlers
│ ├── legalHandlers.js
│ └── registerDoc.js
├── mitra
│ ├── mitraHandlers.js
│ └── worklogHandlers.js
├── shared
│ ├── auth
│ │ └── firebaseAdmin.js
│ ├── db
│ │ └── supabase.js
│ ├── http
│ │ ├── body.js
│ │ ├── cors.js
│ │ └── respond.js
│ └── supabase
│ ├── client.js
│ └── storage.js
├── src
│ ├── db
│ │ ├── schema.sql
│ │ └── supabase.js
│ ├── handlers
│ │ ├── customerHandlers.js
│ │ ├── evidenceHandlers.js
│ │ └── legalHandlers.js
│ ├── middleware
│ │ ├── adminCode.js
│ │ ├── auth.js
│ │ ├── cors.js
│ │ └── role.js
│ └── utils
│ ├── errors.js
│ └── json.js
├── package.json
├── README.md
└── vercel.json

