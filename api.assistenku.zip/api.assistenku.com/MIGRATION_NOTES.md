# MIGRATION_NOTES

## File/Folder Dipindah ke _legacy_from_repo

Berikut struktur lama yang tidak ada di ZIP referensi dipindahkan ke `_legacy_from_repo/`:

- README.md
- admin/
- api/
- app/
- legalworkspace/ (struktur lama)
- mitra/
- shared/
- src/
- package.json
- vercel.json
- _zip_reference/

## Struktur Baru (Sesuai ZIP)

- `assistenku/` berisi endpoint admin/customer/mitra.
- `legalworkspace/` berisi seluruh struktur legalworkspace, termasuk `api/`, `app/`, `admin/`, `shared/`, `src/`, `vercel.json`, dan `package.json`.

## Risiko Breaking

- Path lama di root (mis. `api/`, `app/`, `admin/`) kini berada di bawah `legalworkspace/`. Pastikan deployment menggunakan path baru sesuai ZIP.
- Endpoint baru untuk layanan assitenku berada di `assistenku/*/api/`.
